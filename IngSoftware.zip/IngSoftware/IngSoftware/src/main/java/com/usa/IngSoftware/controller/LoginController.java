package com.usa.IngSoftware.controller;


import com.usa.IngSoftware.services.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController {

    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public String login(@RequestParam("userName") String userName,
                        @RequestParam("password") String password) {
        if (authService.autenticar(userName, password)) {
            return "redirect:/dashboard"; // Redireccionar a la página de inicio de sesión exitosa
        } else {
            return "redirect:/login?error"; // Redireccionar a la página de inicio de sesión con error
        }
    }
}
