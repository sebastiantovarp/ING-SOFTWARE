package com.usa.IngSoftware.services;

import com.usa.IngSoftware.entities.Persona;
import com.usa.IngSoftware.repository.PersonaRepository;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    @Autowired
    private PersonaRepository personaRepository;

    public boolean autenticar(String username, String password) {

        try {
            Persona persona = personaRepository.findByUserName(username);

            if (persona == null) {
                return false; // Usuario no encontrado
            } else {
                // Comprobar la contraseña
                String storedPassword = persona.getPassword();
                if (!storedPassword.equals(password)) {
                    return false; // Contraseña incorrecta
                }
            }

            return true; // Autenticación exitosa

        } catch (Exception e) {
            return false; // Usuario no encontrado
        }
    }
}
