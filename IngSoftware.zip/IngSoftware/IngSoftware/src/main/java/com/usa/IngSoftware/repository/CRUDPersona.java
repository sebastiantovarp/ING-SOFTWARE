package com.usa.IngSoftware.repository;

import com.usa.IngSoftware.entities.Persona;
import org.springframework.data.repository.CrudRepository;

import javax.swing.text.html.Option;
import java.util.Optional;


public interface CRUDPersona extends CrudRepository<Persona, Long> {
    Persona findByUserName(String userName); //CrudRepository recibe tipo de clase y su llave primaria.

    Optional<Persona> findByPassword(String password); //CrudRepository
}